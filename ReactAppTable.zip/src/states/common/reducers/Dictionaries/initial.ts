import { IState } from './IState';

export const initialState: IState = {
  sex: {
    dictionary: [],
  },
};
