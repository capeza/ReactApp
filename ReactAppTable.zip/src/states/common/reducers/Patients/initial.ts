import { IState } from './IState';

export const initialState: IState = {
  items:[],
};
