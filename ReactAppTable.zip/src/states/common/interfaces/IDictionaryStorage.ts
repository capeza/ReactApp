export interface IDictionaryStorage<T> {
    dictionary: T;
}
