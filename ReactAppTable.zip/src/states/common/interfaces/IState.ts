export interface IState<T> {
    dictionary: T;
}