import {defaultListExtensions} from '../defaults';
import { Fields } from '../../../../../states/common/classes/Patient';

export const patientColumns: Fields[] = defaultListExtensions.columns;
